import React from 'react'
import './C001.css'

export default function C001() {
  return (
    <div>
        <h3 className='title01'>
            My First React JS App ! Hi ALL
        </h3>
        <h4>17 Sep 2022</h4>

            <h5 style={{
                color : "magenta",
                fontSize : "38px",
                fontFamily : "poppins"
            }}>
            <u>Good Morning</u>
        </h5>
    </div>
  )
}
